import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { MapPin, Navigation, Clock, TrendingDown, Ambulance } from "lucide-react";

const RouteMap = () => {
  // Mock data for demonstration
  const routeInfo = {
    distance: "12.4 km",
    eta: "15 min",
    signalsAhead: 8,
    optimizedSignals: 5,
  };

  return (
    <div className="flex-1 space-y-6 p-6">
      <div className="animate-fade-in-up">
        <h1 className="text-3xl font-bold tracking-tight">Live Route Map</h1>
        <p className="text-muted-foreground">Real-time tracking and traffic optimization</p>
      </div>

      <div className="grid gap-6 lg:grid-cols-3">
        {/* Map Section */}
        <div className="lg:col-span-2 space-y-4">
          <Card className="card-neuro overflow-hidden">
            <CardContent className="p-0">
              {/* Map placeholder */}
              <div className="relative h-[500px] bg-gradient-to-br from-muted via-accent/30 to-muted">
                <div className="absolute inset-0 flex items-center justify-center">
                  <div className="text-center space-y-4">
                    <div className="relative">
                      <MapPin className="h-16 w-16 mx-auto text-primary animate-bounce" />
                      <div className="absolute -bottom-2 left-1/2 -translate-x-1/2 h-4 w-4 rounded-full bg-primary blur-md animate-pulse" />
                    </div>
                    <p className="text-muted-foreground">
                      Live map integration will display here
                    </p>
                    <p className="text-sm text-muted-foreground">
                      Showing ambulance location, route, and optimized signals
                    </p>
                  </div>
                </div>

                {/* Simulated route markers */}
                <div className="absolute top-10 left-10 flex items-center gap-2 rounded-lg border border-border bg-card px-3 py-2 shadow-lg">
                  <div className="h-3 w-3 rounded-full bg-emergency pulse-emergency" />
                  <span className="text-sm font-medium">Ambulance Location</span>
                </div>

                <div className="absolute bottom-10 right-10 flex items-center gap-2 rounded-lg border border-border bg-card px-3 py-2 shadow-lg">
                  <div className="h-3 w-3 rounded-full bg-success" />
                  <span className="text-sm font-medium">Hospital Destination</span>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Route Info Panel */}
        <div className="space-y-4 animate-stagger">
          <Card className="card-neuro border-primary/20 bg-gradient-to-br from-primary/5 to-transparent">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Ambulance className="h-5 w-5 text-emergency pulse-emergency" />
                Active Emergency
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-sm text-muted-foreground">From:</span>
                  <span className="text-sm font-medium">Main St & 5th Ave</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-muted-foreground">To:</span>
                  <span className="text-sm font-medium">City General Hospital</span>
                </div>
              </div>
              <div className="h-px bg-border" />
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1">
                  <p className="text-xs text-muted-foreground">Distance</p>
                  <p className="text-lg font-bold text-primary">{routeInfo.distance}</p>
                </div>
                <div className="space-y-1">
                  <p className="text-xs text-muted-foreground">ETA</p>
                  <p className="text-lg font-bold text-success">{routeInfo.eta}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="card-neuro">
            <CardHeader>
              <CardTitle className="text-base">Traffic Signals</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">Signals Ahead</span>
                <Badge variant="outline" className="font-mono">
                  {routeInfo.signalsAhead}
                </Badge>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">Being Optimized</span>
                <Badge className="bg-success text-success-foreground font-mono">
                  {routeInfo.optimizedSignals}
                </Badge>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">Time Saved</span>
                <span className="text-sm font-bold text-success flex items-center gap-1">
                  <TrendingDown className="h-4 w-4" />
                  ~3.5 min
                </span>
              </div>
            </CardContent>
          </Card>

          <Card className="card-neuro">
            <CardHeader>
              <CardTitle className="text-base">Upcoming Signals</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {[
                  { name: "Junction A", distance: "0.8 km", status: "optimizing", phase: "green" },
                  { name: "Junction B", distance: "2.1 km", status: "optimizing", phase: "green" },
                  { name: "Junction C", distance: "3.5 km", status: "pending", phase: "red" },
                  { name: "Junction D", distance: "4.2 km", status: "pending", phase: "yellow" },
                ].map((signal, index) => (
                  <div
                    key={index}
                    className="flex items-center justify-between rounded-lg border border-border bg-muted/50 p-3"
                  >
                    <div className="flex items-center gap-3">
                      <div
                        className={`h-3 w-3 rounded-full ${
                          signal.phase === "green"
                            ? "bg-success signal-active"
                            : signal.phase === "yellow"
                            ? "bg-warning"
                            : "bg-destructive"
                        }`}
                      />
                      <div>
                        <p className="text-sm font-medium">{signal.name}</p>
                        <p className="text-xs text-muted-foreground">{signal.distance}</p>
                      </div>
                    </div>
                    {signal.status === "optimizing" && (
                      <Badge variant="outline" className="bg-success/10 text-success border-success/20">
                        <Clock className="h-3 w-3 mr-1" />
                        Priority
                      </Badge>
                    )}
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default RouteMap;

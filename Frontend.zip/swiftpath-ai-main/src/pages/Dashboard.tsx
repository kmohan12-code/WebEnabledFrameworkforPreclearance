import { useState } from "react";
import { MapPin, Navigation, Plus } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { useNavigate } from "react-router-dom";

const Dashboard = () => {
  const [accidentLocation, setAccidentLocation] = useState("");
  const [hospitalDestination, setHospitalDestination] = useState("");
  const navigate = useNavigate();

  const handleStartRoute = () => {
    if (accidentLocation && hospitalDestination) {
      navigate("/route-map");
    }
  };

  const hospitals = [
    "City General Hospital",
    "St. Mary's Medical Center",
    "Emergency Care Hospital",
    "Metro Health Center",
  ];

  return (
    <div className="flex-1 space-y-6 p-6">
      <div className="animate-fade-in-up">
        <h1 className="text-3xl font-bold tracking-tight">Driver Dashboard</h1>
        <p className="text-muted-foreground">
          Enter emergency details to start traffic optimization
        </p>
      </div>

      <div className="grid gap-6 lg:grid-cols-2 animate-stagger">
        {/* Location Input Card */}
        <Card className="card-neuro card-neuro-hover">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <MapPin className="h-5 w-5 text-emergency" />
              Accident Location
            </CardTitle>
            <CardDescription>
              Enter or select the emergency location
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="accident-location">Location Address</Label>
              <div className="relative">
                <MapPin className="absolute left-3 top-3 h-5 w-5 text-muted-foreground" />
                <Input
                  id="accident-location"
                  placeholder="Enter street address or landmark"
                  value={accidentLocation}
                  onChange={(e) => setAccidentLocation(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>

            <div className="rounded-lg border border-border bg-muted/50 p-4">
              <div className="h-48 flex items-center justify-center text-muted-foreground">
                <div className="text-center space-y-2">
                  <MapPin className="h-12 w-12 mx-auto opacity-50" />
                  <p className="text-sm">Map preview will appear here</p>
                  <Button variant="outline" size="sm">
                    <Plus className="h-4 w-4 mr-2" />
                    Pin Location
                  </Button>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Hospital Selection Card */}
        <Card className="card-neuro card-neuro-hover">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Navigation className="h-5 w-5 text-success" />
              Destination Hospital
            </CardTitle>
            <CardDescription>
              Select the nearest available hospital
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="hospital">Hospital Name</Label>
              <Input
                id="hospital"
                placeholder="Search hospitals..."
                value={hospitalDestination}
                onChange={(e) => setHospitalDestination(e.target.value)}
                list="hospitals"
              />
              <datalist id="hospitals">
                {hospitals.map((hospital) => (
                  <option key={hospital} value={hospital} />
                ))}
              </datalist>
            </div>

            <div className="space-y-2">
              <Label className="text-sm text-muted-foreground">Quick Select</Label>
              <div className="grid gap-2">
                {hospitals.map((hospital) => (
                  <Button
                    key={hospital}
                    variant="outline"
                    onClick={() => setHospitalDestination(hospital)}
                    className="justify-start"
                  >
                    <Navigation className="h-4 w-4 mr-2 text-success" />
                    {hospital}
                  </Button>
                ))}
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Start Emergency Button */}
      <Card className="card-neuro border-2 border-emergency/20 bg-gradient-to-br from-emergency/5 to-transparent">
        <CardContent className="pt-6">
          <div className="flex flex-col items-center gap-4 text-center sm:flex-row sm:justify-between sm:text-left">
            <div className="space-y-1">
              <h3 className="text-xl font-semibold">Ready to Start Emergency Route</h3>
              <p className="text-sm text-muted-foreground">
                Traffic signals will be optimized along your route using AI
              </p>
            </div>
            <Button
              size="lg"
              onClick={handleStartRoute}
              disabled={!accidentLocation || !hospitalDestination}
              className="bg-gradient-to-r from-emergency to-emergency-glow text-emergency-foreground shadow-lg hover:shadow-xl transition-all px-8 pulse-emergency"
            >
              <Navigation className="h-5 w-5 mr-2" />
              Start Emergency Route
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Statistics Cards */}
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {[
          { label: "Today's Emergencies", value: "12", color: "text-emergency" },
          { label: "Avg. Response Time", value: "8.5 min", color: "text-success" },
          { label: "Signals Optimized", value: "247", color: "text-primary" },
          { label: "Time Saved Today", value: "42 min", color: "text-warning" },
        ].map((stat, index) => (
          <Card key={index} className="card-neuro">
            <CardContent className="pt-6">
              <div className="space-y-2">
                <p className="text-sm text-muted-foreground">{stat.label}</p>
                <p className={`text-3xl font-bold ${stat.color}`}>{stat.value}</p>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
};

export default Dashboard;

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Calendar, Download, Search } from "lucide-react";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";

const EmergencyLogs = () => {
  // Mock emergency log data
  const logs = [
    {
      id: "ER-2024-001",
      date: "2024-01-15",
      time: "14:23",
      from: "Main St & 5th Ave",
      to: "City General Hospital",
      distance: "12.4 km",
      normalTime: "22 min",
      optimizedTime: "15 min",
      timeSaved: "7 min",
      signalsCleared: 8,
    },
    {
      id: "ER-2024-002",
      date: "2024-01-15",
      time: "09:45",
      from: "Park Road Junction",
      to: "St. Mary's Medical",
      distance: "8.2 km",
      normalTime: "16 min",
      optimizedTime: "11 min",
      timeSaved: "5 min",
      signalsCleared: 6,
    },
    {
      id: "ER-2024-003",
      date: "2024-01-14",
      time: "18:12",
      from: "Highway Exit 7",
      to: "Emergency Care Hospital",
      distance: "15.8 km",
      normalTime: "28 min",
      optimizedTime: "19 min",
      timeSaved: "9 min",
      signalsCleared: 11,
    },
    {
      id: "ER-2024-004",
      date: "2024-01-14",
      time: "11:33",
      from: "Market St & 3rd Ave",
      to: "Metro Health Center",
      distance: "6.5 km",
      normalTime: "14 min",
      optimizedTime: "9 min",
      timeSaved: "5 min",
      signalsCleared: 5,
    },
    {
      id: "ER-2024-005",
      date: "2024-01-13",
      time: "22:47",
      from: "Downtown Plaza",
      to: "City General Hospital",
      distance: "10.1 km",
      normalTime: "19 min",
      optimizedTime: "13 min",
      timeSaved: "6 min",
      signalsCleared: 7,
    },
  ];

  const totalTimeSaved = logs.reduce((acc, log) => {
    const mins = parseInt(log.timeSaved.split(" ")[0]);
    return acc + mins;
  }, 0);

  return (
    <div className="flex-1 space-y-6 p-6">
      <div className="animate-fade-in-up">
        <h1 className="text-3xl font-bold tracking-tight">Emergency Logs</h1>
        <p className="text-muted-foreground">Complete history of ambulance routes and optimizations</p>
      </div>

      {/* Summary Stats */}
      <div className="grid gap-4 sm:grid-cols-4 animate-stagger">
        <Card className="card-neuro border-primary/20 bg-gradient-to-br from-primary/5 to-transparent">
          <CardContent className="pt-6">
            <div className="space-y-1">
              <p className="text-sm text-muted-foreground">Total Emergencies</p>
              <p className="text-3xl font-bold text-primary">{logs.length}</p>
            </div>
          </CardContent>
        </Card>

        <Card className="card-neuro border-success/20 bg-gradient-to-br from-success/5 to-transparent">
          <CardContent className="pt-6">
            <div className="space-y-1">
              <p className="text-sm text-muted-foreground">Total Time Saved</p>
              <p className="text-3xl font-bold text-success">{totalTimeSaved} min</p>
            </div>
          </CardContent>
        </Card>

        <Card className="card-neuro border-warning/20 bg-gradient-to-br from-warning/5 to-transparent">
          <CardContent className="pt-6">
            <div className="space-y-1">
              <p className="text-sm text-muted-foreground">Avg Time Saved</p>
              <p className="text-3xl font-bold text-warning">
                {Math.round(totalTimeSaved / logs.length)} min
              </p>
            </div>
          </CardContent>
        </Card>

        <Card className="card-neuro">
          <CardContent className="pt-6">
            <div className="space-y-1">
              <p className="text-sm text-muted-foreground">Signals Optimized</p>
              <p className="text-3xl font-bold">
                {logs.reduce((acc, log) => acc + log.signalsCleared, 0)}
              </p>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Filters and Search */}
      <Card className="card-neuro">
        <CardHeader>
          <CardTitle className="text-base">Filters</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col gap-4 sm:flex-row">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
              <Input placeholder="Search by location or hospital..." className="pl-9" />
            </div>
            <div className="flex gap-2">
              <Button variant="outline" className="gap-2">
                <Calendar className="h-4 w-4" />
                Date Range
              </Button>
              <Button variant="outline" className="gap-2">
                <Download className="h-4 w-4" />
                Export
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Logs Table */}
      <Card className="card-neuro">
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Emergency ID</TableHead>
                  <TableHead>Date & Time</TableHead>
                  <TableHead>From</TableHead>
                  <TableHead>To</TableHead>
                  <TableHead className="text-right">Distance</TableHead>
                  <TableHead className="text-right">Normal Time</TableHead>
                  <TableHead className="text-right">Optimized Time</TableHead>
                  <TableHead className="text-right">Time Saved</TableHead>
                  <TableHead className="text-right">Signals</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {logs.map((log) => (
                  <TableRow key={log.id} className="hover:bg-muted/50">
                    <TableCell className="font-mono font-medium">{log.id}</TableCell>
                    <TableCell>
                      <div className="space-y-1">
                        <p className="text-sm font-medium">{log.date}</p>
                        <p className="text-xs text-muted-foreground">{log.time}</p>
                      </div>
                    </TableCell>
                    <TableCell className="max-w-[200px]">
                      <p className="truncate text-sm">{log.from}</p>
                    </TableCell>
                    <TableCell className="max-w-[200px]">
                      <p className="truncate text-sm">{log.to}</p>
                    </TableCell>
                    <TableCell className="text-right font-medium">{log.distance}</TableCell>
                    <TableCell className="text-right text-muted-foreground">
                      {log.normalTime}
                    </TableCell>
                    <TableCell className="text-right font-medium text-primary">
                      {log.optimizedTime}
                    </TableCell>
                    <TableCell className="text-right">
                      <Badge className="bg-success text-success-foreground">
                        {log.timeSaved}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-right">
                      <Badge variant="outline">{log.signalsCleared}</Badge>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default EmergencyLogs;

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Clock, CheckCircle2, AlertCircle } from "lucide-react";

const TrafficSignals = () => {
  // Mock traffic signal data
  const signals = [
    {
      id: 1,
      name: "Main St & 1st Ave",
      phase: "green",
      timeRemaining: 45,
      priority: true,
      status: "optimized",
    },
    {
      id: 2,
      name: "Park Rd & 2nd Ave",
      phase: "green",
      timeRemaining: 38,
      priority: true,
      status: "optimized",
    },
    {
      id: 3,
      name: "City Center Junction",
      phase: "yellow",
      timeRemaining: 5,
      priority: false,
      status: "normal",
    },
    {
      id: 4,
      name: "Highway Exit 5",
      phase: "green",
      timeRemaining: 52,
      priority: true,
      status: "optimized",
    },
    {
      id: 5,
      name: "Hospital Approach",
      phase: "green",
      timeRemaining: 60,
      priority: true,
      status: "optimized",
    },
    {
      id: 6,
      name: "Market St Junction",
      phase: "red",
      timeRemaining: 28,
      priority: false,
      status: "normal",
    },
  ];

  const getPhaseColor = (phase: string) => {
    switch (phase) {
      case "green":
        return "bg-success";
      case "yellow":
        return "bg-warning";
      case "red":
        return "bg-destructive";
      default:
        return "bg-muted";
    }
  };

  return (
    <div className="flex-1 space-y-6 p-6">
      <div className="animate-fade-in-up">
        <h1 className="text-3xl font-bold tracking-tight">Traffic Signal Status</h1>
        <p className="text-muted-foreground">Real-time signal phases and AI optimization</p>
      </div>

      {/* Summary Cards */}
      <div className="grid gap-4 sm:grid-cols-3 animate-stagger">
        <Card className="card-neuro border-success/20 bg-gradient-to-br from-success/5 to-transparent">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div className="space-y-1">
                <p className="text-sm text-muted-foreground">Optimized Signals</p>
                <p className="text-3xl font-bold text-success">5</p>
              </div>
              <CheckCircle2 className="h-10 w-10 text-success" />
            </div>
          </CardContent>
        </Card>

        <Card className="card-neuro border-warning/20 bg-gradient-to-br from-warning/5 to-transparent">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div className="space-y-1">
                <p className="text-sm text-muted-foreground">Transitioning</p>
                <p className="text-3xl font-bold text-warning">1</p>
              </div>
              <Clock className="h-10 w-10 text-warning" />
            </div>
          </CardContent>
        </Card>

        <Card className="card-neuro border-muted bg-gradient-to-br from-muted/20 to-transparent">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div className="space-y-1">
                <p className="text-sm text-muted-foreground">Normal Operation</p>
                <p className="text-3xl font-bold">2</p>
              </div>
              <AlertCircle className="h-10 w-10 text-muted-foreground" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Signal Grid */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        {signals.map((signal, index) => (
          <Card
            key={signal.id}
            className={`card-neuro card-neuro-hover animate-fade-in-up ${
              signal.priority ? "border-primary/30" : ""
            }`}
            style={{ animationDelay: `${index * 0.1}s` }}
          >
            <CardHeader className="pb-3">
              <div className="flex items-start justify-between">
                <CardTitle className="text-base font-semibold">{signal.name}</CardTitle>
                {signal.priority && (
                  <Badge className="bg-success text-success-foreground">
                    Priority
                  </Badge>
                )}
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              {/* Traffic Light Visual */}
              <div className="flex items-center justify-center rounded-lg border border-border bg-muted/50 p-6">
                <div className="space-y-3">
                  <div
                    className={`h-12 w-12 rounded-full border-2 ${
                      signal.phase === "red"
                        ? "bg-destructive border-destructive signal-active"
                        : "bg-muted border-border opacity-30"
                    }`}
                  />
                  <div
                    className={`h-12 w-12 rounded-full border-2 ${
                      signal.phase === "yellow"
                        ? "bg-warning border-warning signal-active"
                        : "bg-muted border-border opacity-30"
                    }`}
                  />
                  <div
                    className={`h-12 w-12 rounded-full border-2 ${
                      signal.phase === "green"
                        ? "bg-success border-success signal-active"
                        : "bg-muted border-border opacity-30"
                    }`}
                  />
                </div>
              </div>

              {/* Signal Info */}
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-sm text-muted-foreground">Current Phase</span>
                  <div className="flex items-center gap-2">
                    <div className={`h-2 w-2 rounded-full ${getPhaseColor(signal.phase)}`} />
                    <span className="text-sm font-medium capitalize">{signal.phase}</span>
                  </div>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-muted-foreground">Time Remaining</span>
                  <span className="text-sm font-mono font-medium">{signal.timeRemaining}s</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-muted-foreground">Status</span>
                  <Badge
                    variant="outline"
                    className={
                      signal.status === "optimized"
                        ? "bg-success/10 text-success border-success/20"
                        : ""
                    }
                  >
                    {signal.status === "optimized" ? "AI Optimized" : "Normal"}
                  </Badge>
                </div>
              </div>

              {/* Progress bar */}
              <div className="space-y-1">
                <div className="h-2 w-full overflow-hidden rounded-full bg-muted">
                  <div
                    className={`h-full ${getPhaseColor(signal.phase)} transition-all duration-1000`}
                    style={{ width: `${(signal.timeRemaining / 60) * 100}%` }}
                  />
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
};

export default TrafficSignals;

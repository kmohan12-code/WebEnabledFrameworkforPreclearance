import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Ambulance, Lock, Mail } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";

const Login = () => {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const navigate = useNavigate();

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    // Mock login - in real app, this would validate credentials
    navigate("/dashboard");
  };

  return (
    <div className="relative flex min-h-screen items-center justify-center overflow-hidden">
      {/* Background with traffic theme */}
      <div 
        className="absolute inset-0 bg-cover bg-center blur-sm brightness-50"
        style={{
          backgroundImage: "url('https://images.unsplash.com/photo-1449824913935-59a10b8d2000?w=1920&q=80')",
        }}
      />
      
      {/* Overlay gradient */}
      <div className="absolute inset-0 bg-gradient-to-br from-primary/30 via-emergency/20 to-primary/30" />

      {/* Emergency lights effect */}
      <div className="absolute left-10 top-10 h-32 w-32 animate-pulse rounded-full bg-emergency/30 blur-3xl" />
      <div className="absolute bottom-10 right-10 h-32 w-32 animate-pulse rounded-full bg-primary/30 blur-3xl animation-delay-1000" />

      {/* Login card */}
      <Card className="relative z-10 w-full max-w-md card-neuro m-4">
        <CardHeader className="space-y-4 text-center">
          <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-2xl bg-gradient-to-br from-primary to-primary-glow text-primary-foreground shadow-lg">
            <Ambulance className="h-8 w-8 pulse-emergency" />
          </div>
          <div>
            <CardTitle className="text-2xl font-bold">Smart Ambulance System</CardTitle>
            <CardDescription className="text-base">
              Traffic Priority Control Portal
            </CardDescription>
          </div>
        </CardHeader>

        <CardContent>
          <form onSubmit={handleLogin} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="email" className="text-sm font-medium">
                Email Address
              </Label>
              <div className="relative">
                <Mail className="absolute left-3 top-3 h-5 w-5 text-muted-foreground" />
                <Input
                  id="email"
                  type="email"
                  placeholder="driver@ambulance.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="pl-10"
                  required
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="password" className="text-sm font-medium">
                Password
              </Label>
              <div className="relative">
                <Lock className="absolute left-3 top-3 h-5 w-5 text-muted-foreground" />
                <Input
                  id="password"
                  type="password"
                  placeholder="••••••••"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="pl-10"
                  required
                />
              </div>
            </div>

            <Button
              type="submit"
              className="w-full bg-gradient-to-r from-primary to-primary-glow text-primary-foreground shadow-lg hover:shadow-xl transition-all"
            >
              Sign In
            </Button>

            <p className="text-center text-sm text-muted-foreground">
              Emergency services only. Authorized personnel access required.
            </p>
          </form>
        </CardContent>
      </Card>
    </div>
  );
};

export default Login;

import { SidebarTrigger } from "@/components/ui/sidebar";
import { Bell, User } from "lucide-react";
import { Button } from "@/components/ui/button";

export function AppNavbar() {
  return (
    <header className="sticky top-0 z-40 flex h-16 items-center gap-4 border-b border-border bg-card px-6">
      <SidebarTrigger />
      
      <div className="flex-1" />

      <div className="flex items-center gap-2">
        <Button variant="ghost" size="icon" className="relative">
          <Bell className="h-5 w-5" />
          <span className="absolute right-2 top-2 h-2 w-2 rounded-full bg-emergency"></span>
        </Button>
        
        <div className="flex items-center gap-3 rounded-lg border border-border bg-muted px-3 py-2">
          <User className="h-5 w-5 text-muted-foreground" />
          <div className="hidden flex-col sm:flex">
            <span className="text-sm font-medium">Driver Name</span>
            <span className="text-xs text-muted-foreground">Active</span>
          </div>
        </div>
      </div>
    </header>
  );
}
